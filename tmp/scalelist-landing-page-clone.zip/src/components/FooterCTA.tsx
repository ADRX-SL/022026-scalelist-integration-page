import React from 'react';
import { motion } from 'motion/react';
import { ArrowRight } from 'lucide-react';

export const FooterCTA = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto">
        <motion.div 
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          className="bg-brand-card rounded-[3rem] p-12 lg:p-24 text-center relative overflow-hidden"
        >
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10 pointer-events-none">
            <div className="absolute top-0 left-0 w-full h-full bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-brand-primary via-transparent to-transparent"></div>
          </div>

          <div className="relative z-10">
            <div className="w-16 h-16 bg-brand-primary rounded-2xl mx-auto mb-8 flex items-center justify-center shadow-xl shadow-blue-500/20">
              <div className="grid grid-cols-2 gap-1">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
                <div className="w-4 h-4 bg-white/50 rounded-sm"></div>
                <div className="w-4 h-4 bg-white/50 rounded-sm"></div>
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
            </div>
            
            <h2 className="text-4xl lg:text-6xl font-bold tracking-tight mb-12">
              Try our data quality for free!
            </h2>
            
            <div className="flex flex-wrap justify-center items-center gap-6">
              <button className="bg-brand-primary hover:bg-blue-600 text-white px-10 py-5 rounded-2xl font-bold text-lg transition-all shadow-xl shadow-blue-500/20">
                Get started for free
              </button>
              <button className="flex items-center gap-2 font-bold text-brand-dark hover:gap-3 transition-all text-lg">
                Talk to Sales <ArrowRight size={20} />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};
