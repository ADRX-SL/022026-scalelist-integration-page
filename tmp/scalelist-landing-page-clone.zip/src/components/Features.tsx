import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export const Features = () => {
  const features = [
    {
      title: "On Social & Professional Profiles",
      tag: "REVEAL DECISION-MAKERS ON ANY SITE OR PROFILE",
      points: [
        "Verified Emails: Get accurate data from any profile.",
        "B2B Mobile Numbers: Build list of accurate mobiles thanks to our B2B data quality.",
        "Easy Push: Push leads to your CRM in one-click."
      ],
      image: "https://picsum.photos/seed/social/600/400"
    },
    {
      title: "On Any Website",
      tag: "FIND CONTACT INFORMATION & BUILD TARGETED LISTS ANYWHERE",
      points: [
        "Full Company View: See org charts, emails, and phone numbers.",
        "Buying Intent & Signals: Identify decision-makers and track company activity.",
        "Effortless List Building: Export leads instantly to your CRM or CSV."
      ],
      image: "https://picsum.photos/seed/web/600/400"
    }
  ];

  return (
    <section className="py-24 px-6 bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-brand-primary text-xs font-bold uppercase tracking-[0.2em] mb-4 block">
            Reveal verified emails and mobile numbers on any site or profile
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold tracking-tight">
            Find Contact Information & <br /> Build Targeted Lists Anywhere
          </h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {features.map((feature, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: idx * 0.2 }}
              className="bg-brand-bg rounded-3xl p-8 lg:p-12 border border-gray-100 flex flex-col"
            >
              <div className="mb-8 rounded-2xl overflow-hidden bg-white border-2 border-dashed border-blue-200 aspect-video flex items-center justify-center p-8 text-center">
                <p className="text-blue-400 font-mono text-sm font-bold uppercase tracking-wider leading-relaxed">
                  {idx === 0 
                    ? "[IMAGE: BROWSER WINDOW SHOWING A SOCIAL PROFILE WITH A SCALELIST SIDE-PANEL EXTENSION OVERLAY REVEALING VERIFIED CONTACT INFORMATION]"
                    : "[IMAGE: BROWSER WINDOW SHOWING A COMPANY WEBSITE WITH A SCALELIST SIDE-PANEL EXTENSION OVERLAY REVEALING DETAILED COMPANY INSIGHTS]"
                  }
                </p>
              </div>
              <div className="mb-6">
                <span className="inline-block px-4 py-1.5 bg-blue-50 text-blue-600 text-[10px] font-bold rounded-full uppercase tracking-wider mb-4">
                  {feature.tag}
                </span>
                <h3 className="text-2xl font-bold">{feature.title}</h3>
              </div>
              <ul className="space-y-4 flex-grow">
                {feature.points.map((point, pIdx) => (
                  <li key={pIdx} className="flex gap-3 text-gray-600 leading-relaxed">
                    <CheckCircle2 size={20} className="text-brand-primary shrink-0 mt-1" />
                    <span>
                      <strong className="text-brand-dark">{point.split(':')[0]}:</strong>
                      {point.split(':')[1]}
                    </span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
