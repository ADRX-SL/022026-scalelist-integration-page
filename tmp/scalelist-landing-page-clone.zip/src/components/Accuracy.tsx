import React from 'react';
import { motion } from 'motion/react';
import { Quote } from 'lucide-react';

export const Accuracy = () => {
  const competitors = [
    { name: 'COMP 1', score: 80 },
    { name: 'COMP 2', score: 71 },
    { name: 'COMP 3', score: 85 },
    { name: 'COMP 4', score: 75 },
    { name: 'COMP 5', score: 87 },
    { name: 'SCALELIST', score: 95, highlight: true }
  ];

  const testimonials = [
    {
      name: "Chris Hackett",
      role: "CEO & Founder @ Firm Growth",
      text: "I love Scalelist – Cannot recommend it enough. It does EVERYTHING you need it to do really well. Easy to use/ navigate and Arnaud and colleagues are always there to lend a hand. Built by people who really care about their product.",
      avatar: "https://picsum.photos/seed/chris-pro/100/100"
    },
    {
      name: "Baptiste Graffin",
      role: "VP of Sales APAC @ Happydemics",
      text: "We use Scalelist everyday. It’s a really good product that helps us find our prospects’ emails and phone numbers.",
      avatar: "https://picsum.photos/seed/baptiste-pro/100/100"
    }
  ];

  return (
    <section className="py-24 px-6 bg-brand-dark text-white rounded-[3rem] mx-4 my-12">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-20">
          <span className="text-gray-400 text-xs font-bold uppercase tracking-[0.2em] mb-4 block">
            JOIN 7,000+ COMPANIES USING SCALELIST
          </span>
          <h2 className="text-4xl lg:text-5xl font-bold tracking-tight">The most accurate data</h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Chart Section */}
          <div className="bg-[#111827] rounded-3xl p-8 lg:p-12 border border-white/5">
            <div className="mb-12">
              <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Data coverage</span>
              <div className="flex items-baseline gap-3 mt-2">
                <p className="text-5xl font-bold">up to 95%</p>
                <p className="text-xs text-gray-400 font-medium">Verified emails + direct dials you can sell with</p>
              </div>
              <p className="text-sm text-gray-400 mt-4">See how we perform against competitors. →</p>
            </div>
            
            <div className="flex items-end gap-2 lg:gap-4 h-[400px] relative pt-16">
              {/* Grid Lines */}
              <div className="absolute inset-0 flex flex-col justify-between pointer-events-none opacity-5 py-16">
                <div className="border-t border-white w-full"></div>
                <div className="border-t border-white w-full"></div>
                <div className="border-t border-white w-full"></div>
                <div className="border-t border-white w-full"></div>
              </div>

              {competitors.map((comp, idx) => (
                <div key={idx} className="flex-1 flex flex-col items-center relative z-10 h-full">
                  <div className="flex flex-col items-center w-full h-full justify-end">
                    <span className="text-[11px] font-bold mb-3">{comp.score}%</span>
                    <motion.div 
                      initial={{ height: 0 }}
                      whileInView={{ height: `${comp.score}%` }}
                      viewport={{ once: true }}
                      transition={{ duration: 1, delay: idx * 0.1 }}
                      className={`w-full bg-[#1e293b] border-t-2 border-white relative group`}
                    >
                      {comp.highlight && (
                        <div className="absolute inset-0 bg-brand-primary/20"></div>
                      )}
                    </motion.div>
                  </div>
                  <span className={`text-[9px] font-bold uppercase tracking-widest mt-6 ${comp.highlight ? 'text-white' : 'text-gray-500'}`}>
                    {comp.name}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Testimonials Grid */}
          <div className="grid gap-6">
            <h3 className="text-2xl font-bold mb-4">Sales Teams Winning with Scalelist's Data</h3>
            {testimonials.map((t, idx) => (
              <motion.div 
                key={idx}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                className="bg-white/5 rounded-2xl p-6 border border-white/10 relative"
              >
                <Quote className="absolute top-6 right-6 text-white/10" size={40} />
                <p className="text-gray-300 mb-6 leading-relaxed italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <img src={t.avatar} alt={t.name} className="w-10 h-10 rounded-full grayscale" referrerPolicy="no-referrer" />
                  <div>
                    <p className="text-sm font-bold">{t.name}</p>
                    <p className="text-[10px] text-gray-500">{t.role}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};
