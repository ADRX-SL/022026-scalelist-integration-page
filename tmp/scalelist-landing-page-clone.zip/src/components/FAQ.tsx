import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Minus, Star, ShieldCheck } from 'lucide-react';

export const Testimonials = () => {
  return (
    <section className="py-24 px-6">
      <div className="max-w-7xl mx-auto space-y-12">
        {/* Large Testimonial */}
        <div className="bg-brand-card rounded-[3rem] p-8 lg:p-16 grid lg:grid-cols-3 gap-12 items-center">
          <div className="lg:col-span-2">
            <h3 className="text-3xl lg:text-4xl font-bold mb-8 leading-tight">
              "I can access the contact data I need instantly"
            </h3>
            <p className="text-lg text-gray-600 mb-10 leading-relaxed">
              The Chrome extension works everywhere, professional networks, websites, CRMs. It's the fastest way we've found emails without breaking our flow.
            </p>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center text-blue-600 font-bold">
                JA
              </div>
              <div>
                <p className="font-bold">Joseph Aboutariya</p>
                <p className="text-sm text-gray-500">Director, Sales Development at FlashIntel</p>
              </div>
            </div>
          </div>
          <div className="rounded-3xl overflow-hidden shadow-2xl rotate-3">
            <img 
              src="https://picsum.photos/seed/joseph/600/800" 
              alt="Joseph" 
              className="w-full"
              referrerPolicy="no-referrer"
            />
          </div>
        </div>

        {/* Awards/Trust Section */}
        <div className="bg-brand-card rounded-[3rem] p-8 lg:p-12 flex flex-wrap items-center justify-between gap-12">
          <div className="max-w-md">
            <div className="flex items-center gap-2 mb-4">
              <div className="flex gap-0.5 text-brand-primary">
                {[...Array(5)].map((_, i) => <Star key={i} size={14} fill="currentColor" />)}
              </div>
              <span className="text-xs font-bold">4.8</span>
              <div className="h-4 w-px bg-gray-300 mx-2"></div>
              <div className="flex items-center gap-1 text-blue-600">
                <ShieldCheck size={14} />
                <span className="text-xs font-bold">GDPR Compliant</span>
              </div>
            </div>
            <h4 className="text-3xl font-bold mb-6">Weekly refreshed data</h4>
            <div className="flex gap-4">
              <button className="bg-brand-primary text-white px-6 py-3 rounded-xl font-bold text-sm">
                Get started for free
              </button>
              <button className="text-sm font-bold underline underline-offset-4">View all reviews</button>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-6">
            {['Most Used 2025', 'Tier 1 Accuracy', 'High Performer', 'Top 50'].map((badge, i) => (
              <div key={i} className="w-24 h-32 bg-white rounded-xl border border-gray-100 flex flex-col items-center justify-center p-4 text-center shadow-sm">
                <div className={`w-10 h-10 rounded-full mb-3 ${i % 2 === 0 ? 'bg-green-100' : 'bg-orange-100'}`}></div>
                <p className="text-[10px] font-bold leading-tight">{badge}</p>
                <p className="text-[8px] text-gray-400 mt-1 uppercase">Clay / G2</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export const FAQ = () => {
  const faqs = [
    {
      q: "How can I find an email address on a social / professional profile using the Chrome extension?",
      a: "Simply navigate to any profile and click the Scalelist icon. Our extension will instantly find and verify the email address for you."
    },
    {
      q: "Is the Email Finder Chrome extension free to use?",
      a: "Yes, we offer a generous free tier that includes 50 credits per month so you can test our data quality."
    },
    {
      q: "What data can I get using the Scalelist Contact Finder Extension?",
      a: "You can get verified business emails, personal emails (when available), direct phone numbers, and company insights."
    },
    {
      q: "Do you integrate with CRMs, enrichment tools, or outbound platforms?",
      a: "Absolutely. We integrate with Salesforce, HubSpot, Pipedrive, and many more via direct integration or Zapier."
    }
  ];

  const [openIdx, setOpenIdx] = useState<number | null>(0);

  return (
    <section className="py-24 px-6">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-16">
          <span className="px-3 py-1 bg-blue-100 text-brand-primary text-[10px] font-bold rounded-full uppercase tracking-widest mb-4 inline-block">
            FAQ
          </span>
          <h2 className="text-4xl font-bold">Frequently asked questions</h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm">
              <button 
                onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                className="w-full flex items-center justify-between p-6 text-left font-bold hover:bg-gray-50 transition-colors"
              >
                <span>{faq.q}</span>
                {openIdx === idx ? <Minus size={20} /> : <Plus size={20} />}
              </button>
              <AnimatePresence>
                {openIdx === idx && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                  >
                    <div className="p-6 pt-0 text-gray-600 leading-relaxed">
                      {faq.a}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
