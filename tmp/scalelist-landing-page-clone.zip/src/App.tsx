import React from 'react';
import { Hero, TrustBar } from './components/Hero';
import { Features } from './components/Features';
import { Accuracy } from './components/Accuracy';
import { Testimonials, FAQ } from './components/FAQ';
import { FooterCTA } from './components/FooterCTA';

export default function App() {
  return (
    <div className="min-h-screen selection:bg-red-100 selection:text-brand-red">
      <main>
        <Hero />
        <TrustBar />
        <Features />
        <Accuracy />
        <Testimonials />
        <FAQ />
        <FooterCTA />
      </main>
      
      <footer className="py-12 border-t border-gray-100 text-center">
        <div className="max-w-7xl mx-auto px-6">
          <p className="text-sm text-gray-400 font-medium">
            © 2026 Scalelist. All rights reserved. Built for high-fidelity data extraction.
          </p>
        </div>
      </footer>
    </div>
  );
}
